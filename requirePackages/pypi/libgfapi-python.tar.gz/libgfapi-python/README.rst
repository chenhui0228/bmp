libgfapi-python
---------------

This is the official python bindings for the
`GlusterFS <http://www.gluster.org/>`_ libgfapi C library interface.

Complete API reference and documentation can be found at
`ReadTheDocs <http://libgfapi-python.readthedocs.io/>`_.

Please follow the `Developer Guide <https://github.com/gluster/libgfapi-python/blob/master/doc/markdown/dev_guide.md>`_ to
contribute code.
