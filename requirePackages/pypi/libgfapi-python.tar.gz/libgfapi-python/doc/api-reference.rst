API Reference
=============

Volume Class
------------

.. autoclass:: gluster.gfapi.Volume
    :members:
    :undoc-members:
    :noindex:

    .. automethod:: gluster.gfapi.Volume.__init__

.. autoclass:: gluster.gfapi.DirEntry
    :members:
    :undoc-members:
    :noindex:

File Class
----------

.. autoclass:: gluster.gfapi.File
    :members:
    :undoc-members:
    :noindex:

    .. automethod:: gluster.gfapi.File.__init__
