=======
Contact
=======

You can get in touch with the developer & user community in any of the
following ways:

* IRC: ``#gluster-dev`` on Freenode
* Mailing list: ``gluster-devel@gluster.org`` (see the `gluster-devel homepage
  <https://www.gluster.org/mailman/listinfo/gluster-devel>`_ for usage details)
