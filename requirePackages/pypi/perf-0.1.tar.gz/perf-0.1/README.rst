perf: Toolkit to run Python benchmarks.

* `perf project homepage at GitHub
  <https://github.com/haypo/perf>`_ (code, bugs)
* `perf documentation
  <https://perf.readthedocs.io/>`_
* `Download latest perf release at the Python Cheeseshop (PyPI)
  <https://pypi.python.org/pypi/perf>`_
* License: MIT

Install perf: ``python3 -m pip install perf``. It requires Python 2.7
or Python 3.

Documentation: see doc/ directory.
