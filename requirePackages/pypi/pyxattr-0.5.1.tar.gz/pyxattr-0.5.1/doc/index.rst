======================================
 Welcome to pylibacl's documentation!
======================================

.. include:: ../README
   :start-line: 2

Contents
--------

.. toctree::
   :maxdepth: 2

   module.rst
   news.rst

Also see the :ref:`search`.
