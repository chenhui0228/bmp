API documentation
=================

This document provides API reference documentation for pyudev.  Refer to the
:doc:`../guide` for an introduction into pyudev.

.. toctree::

   pyudev
   pyqt4
   pyside
   glib
   wx
